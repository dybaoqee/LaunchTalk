
module.exports = function(grunt) {

	grunt.initConfig({

		pkg: grunt.file.readJSON('package.json'),

		watch: {
			js: {
				files: ['src/js/*'],
				tasks: ['uglify']
			},
			sass: {
				files: ['src/sass/*'],
				tasks: ['sass', 'cssmin']
			}
		},

		sass: {
			dist: {
				files: [{
					src: 'src/sass/eckoplugin.scss',
					dest: 'src/sass/build/eckoplugin.css',
					ext: '.css'
				}]
			}
		},

		cssmin: {
			combine: {
				files: {
					'assets/css/eckoplugin.css': ['src/sass/build/eckoplugin.css']
				}
			}
		},

		uglify: {
			js: {
				files: {
					'assets/js/eckoplugin.js': ['src/js/eckoplugin.js']
				}
			}
		}

	});

	grunt.loadNpmTasks('grunt-contrib-sass');
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	grunt.loadNpmTasks('grunt-contrib-uglify');
	grunt.loadNpmTasks('grunt-contrib-watch');

	grunt.registerTask('default', ['sass', 'cssmin', 'uglify', 'watch']);
	grunt.registerTask('build', ['sass', 'cssmin', 'uglify']);

};
